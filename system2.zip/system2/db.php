<?php
    
    $conn=mysqli_connect("localhost","root","","system");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
?>