<?php
// Include database connection file
require_once "../db.php";

    if(count($_POST)>0) {
    mysqli_query($conn,"UPDATE offices set  Office='" . $_POST['Office'] . "', Number='" . $_POST['Number'] . "' ,Campus='" . $_POST['Campus'] . "' WHERE uid='" . $_POST['id'] . "'");
     
     header("location: tables-data.php");
     exit();
    }
    $result = mysqli_query($conn,"SELECT * FROM offices WHERE   uid='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);
  
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <?php include "head.php"; ?>
</head>
<body>

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group">
                            <label>Office</label>
                            <input type="text" name="Office" class="form-control" value="<?php echo $row["Office"]; ?>" maxlength="50" required="">
                            
                        </div>
                        <div class="form-group ">
                            <label>Extension/Number</label>
                            <input type="number" name="Number" class="form-control" value="<?php echo $row["Number"]; ?>" maxlength="30" required="">
                        </div>
                        <div class="form-group">
                            <label>Names</label>
                            <input type="text" name="Names" class="form-control" value="<?php echo $row["Names"]; ?>" maxlength="12"required="">
                        </div>
                        <div class="form-group">
                            <label>Campus</label>
                            <input type="text" name="Campus" class="form-control" value="<?php echo $row["Campus"]; ?>" maxlength="12"required="">
                        </div>
                        <input type="hidden" name="id" value="<?php echo $row["uid"]; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index1.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>  
        </div>
</body>
</html>