<html> 
<head> 
	<meta  http-equiv="Content-Type" content="text/html;  charset=iso-8859-1"> 
	<title>Search  Contacts</title> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
	<style type="text/css">
    
		.wrapper{
            width: 650px;
            margin: 0 auto;
			margin-top:50px;
        }
       p {
		   font-size:20px;
	   }
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
		.wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
		
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head> 
<body> 
	<div class="wrapper">
	<?php 
    include"../db.php";
		if(isset($_POST['submit'])){ 
			if(isset($_GET['go'])){ 
				if(preg_match("/^[  a-zA-Z]+/", $_POST['name'])){ 
					$name=$_POST['name']; 
					
					//-query  the database table 
					$sql="SELECT  uid, Office, Number, Names, Campus FROM offices WHERE Office LIKE '%".$name."%' OR Names LIKE '%" . $name ."%'"; 
					//-run  the query against the mysql query function 
					$result=mysqli_query($conn,$sql);
					//-create  while loop and loop through result set 
					if(mysqli_num_rows($result) > 0){
						while($row=mysqli_fetch_array($result)){ 
							$Id =$row['uid']; 
							$Office =$row['Office']; 
							$Number=$row['Number'];
							$Names=$row['Names'];
                            $Campus=$row['Campus'];
							//-display the result of the array 
							echo "<table class='table table-bordered table-striped table-hover '>";
								echo "<thead>";
									echo "<tr>";
										echo "<th>#</th>";
										echo "<th>Office</th>";
										echo "<th>Extension/Number</th>";
										echo "<th>Names</th>";
                                        echo "<th>Campus</th>";
									echo "</tr>";
								echo "</thead>";
								echo "<tbody>";
									echo "<tr>";
										echo "<td>" . $row['uid'] . "</td>";
										echo "<td>" . $row['Office'] . "</td>";
										echo "<td>" . $row['Number'] . "</td>";
										echo "<td>" . $row['Names'] . "</td>";
                                        echo "<td>" . $row['Campus'] . "</td>";
									echo "</tr>";
								echo "</tbody>";                            
							echo "</table>";
							echo "<p><a href='tables-data.php' class='btn btn-primary'>Back</a></p>";
						} 
					} else {
						echo "<p>No matches found</p>";
						echo "<p><a href='tables-data.php' class='btn btn-primary'>Back</a></p>";
					}
				} else { 
					echo  "<p>Please enter a search query</p>"; 
					echo "<p><a href='tables-data.php' class='btn btn-primary'>Back</a></p>";
				} 
			} 
		} 
	?> 
	</div>
</body> 
</html> 