<?php
require_once "../db.php";

if(isset($_POST['save']))
{    

     $Office = $_POST['Office'];
     $Number= $_POST['Number'];
     $Names= $_POST['name'];
     $Campus=$_POST['Campus'];
     $sql = "INSERT INTO offices (Office,Number,Names,Campus)
     VALUES ('$Office','$Number','$Names','$Campus')";
     if (mysqli_query($conn, $sql)) {
        header("location: tables-data.php");
        exit();
     } else {
        echo "Error: " . $sql . "
" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <?php include "head.php"; ?>
</head>
<body>
 
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add  record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group">
                            <label>Office</label>
                            <input type="text" name="Office" class="form-control" value="" maxlength="50" required="">
                        </div>
                        <div class="form-group ">
                            <label>Extension/Number</label>
                            <input type="number" name="Number" class="form-control" value="" maxlength="30" required="">
                        </div>
                        <div class="form-group">
                            <label>Names</label>
                            <input type="text" name="name" class="form-control" value="" maxlength="30" required="">
                        </div>
                        <div class="form-group">
                            <label>Campus</label>
                            <input type="text" name="campus" class="form-control" value="" maxlength="12" required="">
                        </div>

                        <input type="submit" class="btn btn-primary" name="save" value="submit">
                        <a href="index1.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>

            </div> 
               
        </div>

</body>
</html>
