<?php
include_once '../db.php';
$sql = "DELETE FROM offices WHERE  uid='" . $_GET["id"] . "'";
if (mysqli_query($conn, $sql)) {
   header("location: tables-data.php");
   exit();
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>