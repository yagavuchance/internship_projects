#admin login details.
admin email:stevo@gmail.com
Admin password:1234567.
